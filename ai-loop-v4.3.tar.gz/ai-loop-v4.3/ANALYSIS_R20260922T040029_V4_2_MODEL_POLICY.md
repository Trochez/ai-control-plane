# Diagnosis — R20260922T040029 / ai-loop v4.2

## Evidence inspected

The production diagnostics archive contained the JSON/HTML/screenshot emitted by:

- `ENSURE_FRESH_PROJECT_DRAFT`
- `ENSURE_CHAT_POLICY`

No user message had been sent before the failure.

## Finding 1 — project-name parsing was still wrong

The target URL is:

`https://chatgpt.com/g/g-p-68782097d6388191b7538c01b189cce8-bot-trading`

but the v4.2 diagnostic recorded:

`projectName = trading`

The old parser used a greedy opaque-id expression and consumed `-bot`, leaving only `trading`.

At the same time, the real UI exposed both:

- composer `aria-label="New chat in Bot_trading"`
- project selector `aria-label="Change project: Bot_trading"`

Therefore the first v4.2 fresh-draft attempt incorrectly classified a valid project draft as `UNKNOWN` even though the UI positively identified the target project.

## Finding 2 — the current Chat UI no longer exposes a literal Sol option in the standard Chat composer

The real DOM showed:

- selected surface: `Chat`
- model/reasoning trigger: `aria-label="Select ChatGPT model"`
- `data-composer-navigation-target="reasoning"`
- `data-selected-reasoning-effort="high"`
- visible trigger text: `High`

The v4.2 broker instead required a selected control matching literal text `GPT-5.6 Sol`. It clicked the reasoning trigger and then searched for that literal option. The menu did not contain such an item, so it raised:

`MODEL_SOL_OPTION_NOT_FOUND`

This was a controller/UI-contract mismatch, not evidence that Sol was unavailable.

## Product contract used by v4.3

The current standard Chat product exposes a reasoning slider rather than a separate Sol/Luna/Terra selector. On eligible paid Chat plans, `Medium` and `High` are powered by GPT-5.6 Sol; `High` is the mandatory ai-loop policy.

Therefore v4.3 proves the required model policy as:

`normal Chat selected + reasoning control selected at High => GPT-5.6 Sol / High`

The controller still fails closed if Chat is not selected or High cannot be positively proven.

## v4.3 remediation

1. Parse the project slug after the full opaque project id, producing `bot_trading` instead of `trading`.
2. Add `Change project: Bot_trading` as a strong active-project signal.
3. Persist `data-composer-navigation-target`, `data-selected-reasoning-effort`, and related control metadata in browser observations.
4. Replace the mandatory literal `GPT-5.6 Sol` menu search in current standard Chat with a reasoning-slider policy verifier.
5. Keep an explicit-model fallback for legacy UI variants.
6. Preserve fail-closed behavior: selected Chat + selected High + Sol policy proof are all required before attachment or Send.
7. Add exact regression tests derived from R20260922T040029.
