# ai-loop v4.4

Production hardening release over v4.2, built from the literal diagnostics of run `R20260922T040029`.

## What v4.3 fixes

v4.2 reached a valid empty `Bot_trading` draft but failed in two related proof layers:

1. the project-name parser extracted `trading` instead of `bot_trading` from the real project URL;
2. the current standard Chat UI exposes the selected reasoning effort (`High`) rather than a literal `GPT-5.6 Sol` menu option, while v4.2 still required that literal option.

v4.3 uses the actual DOM contract:

- `Change project: Bot_trading` and `New chat in Bot_trading` are positive project signals;
- `Chat` must be selected;
- `data-selected-reasoning-effort="high"` / visible `High` must be positively proven;
- in current standard paid Chat, High maps to GPT-5.6 Sol;
- legacy explicit Sol model selection remains a fallback only.

## Verify locally

```bash
./bin/verify-v4.3-local
```

Expected tail:

```text
BROKER_TEST_V4_3=PASS
SELFTEST_V4_3_R040029_PROJECT_IDENTITY=PASS
SELFTEST_V4_3_R040029_MODEL_POLICY=PASS
SELFTEST_V4_3_RELEASE_CANDIDATE_LOCAL=PASS
VERIFY_V4_5_LOCAL=PASS version=4.5.0
```

## Install

```bash
./install.sh
```

Expected:

```text
INSTALL_V4_5=PASS version=4.5.0
```

## Preflight

```bash
/opt/ai-loop/bin/preflight-v4.3 /path/to/PLAN.md
```

## Start a new run

```bash
/opt/ai-loop/bin/start-loop-v3 /path/to/PLAN.md
```

The `v3` filename is retained for compatibility; the daemon reports `version=4.5.0`.
